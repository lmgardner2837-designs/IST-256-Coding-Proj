const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

let submissions = [];
let returnsDocs = [];
let nextSubmissionId = 1;
let nextReturnsId = 1;


app.post("/api/submissions", (req, res) => {
   const body = req.body || {};

   if (!body.name || !body.type) {
      return res
         .status(400)
         .json({ success: false, message: "Missing name or type." });
   }

   const submission = {
      id: nextSubmissionId++,
      name: body.name,
      address: body.address || "",
      city: body.city || "",
      state: body.state || "",
      zip: body.zip || "",
      card: body.card || "",
      cvv: body.cvv || "",
      description: body.description || "",
      type: body.type || "Billing",
      status: "Pending",
      createdAt: new Date().toISOString()
   };

   submissions.push(submission);

   res.json({ success: true, submission });
});

app.get("/api/submissions", (req, res) => {
   const { status } = req.query;
   let result = submissions;
   if (status) result = result.filter((s) => s.status === status);
   res.json(result);
});

app.put("/api/submissions/:id", (req, res) => {
   const id = parseInt(req.params.id, 10);
   const { status } = req.body;

   const submission = submissions.find((s) => s.id === id);
   if (!submission) {
      return res
         .status(404)
         .json({ success: false, message: "Submission not found." });
   }

   if (status) {
      submission.status = status;
   }

   res.json({ success: true, submission });
});


app.post("/api/returns", (req, res) => {
   const body = req.body || {};
   if (!Array.isArray(body.items) || body.items.length === 0) {
      return res
         .status(400)
         .json({ success: false, message: "No items provided for return." });
   }

   const returnsDoc = {
      id: nextReturnsId++,
      shopperId: body.shopperId || "Unknown",
      items: body.items,
      createdAt: body.createdAt || new Date().toISOString()
   };

   returnsDocs.push(returnsDoc);

   res.json({ success: true, returnsDoc });
});

app.get("/api/returns", (req, res) => {
   res.json(returnsDocs);
});

app.listen(PORT, () => {
   console.log(`API server running at http://localhost:${PORT}`);
});