
document.addEventListener("DOMContentLoaded", () => {
  const API_BASE = "http://127.0.0.1:3000";

  const form = document.getElementById("signupForm");
  const userData = document.getElementById("userData");

  const nameInput = document.getElementById("fullName");
  const emailInput = document.getElementById("email");
  const phoneInput = document.getElementById("phone");
  const ageInput = document.getElementById("age");
  const addressInput = document.getElementById("address");

  const nameError = document.getElementById("nameError");
  const emailError = document.getElementById("emailError");
  const ageError = document.getElementById("ageError");
  const addressError = document.getElementById("addressError");

  function clearErrors() {
    nameError.textContent = "";
    emailError.textContent = "";
    ageError.textContent = "";
    addressError.textContent = "";
  }

  function validate() {
    clearErrors();
    let good = true;

    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    const phone = phoneInput.value.trim();
    const age = ageInput.value.trim();
    const address = addressInput.value.trim();

    if (name.length < 2) {
      nameError.textContent = "Please enter your full name.";
      good = false;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      emailError.textContent = "Enter a valid email (name@example.com).";
      good = false;
    }

    const ageNum = Number(age);
    if (!Number.isInteger(ageNum) || ageNum < 1 || ageNum > 120) {
      ageError.textContent = "Enter a whole number between 1 and 120.";
      good = false;
    }

    if (address.length < 5) {
      addressError.textContent = "Please enter at least 5 characters.";
      good = false;
    }

    if (
      phone &&
      !/^(\+?\d{1,3}[\s.-]?)?(\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4})$/.test(phone)
    ) {
      emailError.textContent =
        (emailError.textContent ? emailError.textContent + " " : "") +
        "If provided, phone must be valid (e.g., 555-123-4567).";
      good = false;
    }

    return good;
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    if (!validate()) return;

    const payload = {
      name: nameInput.value.trim(),
      email: emailInput.value.trim(),
      phone: phoneInput.value.trim() || null,
      age: Number(ageInput.value.trim()),
      address: addressInput.value.trim(),
    };

    // show JSON preview on the page
    userData.textContent = JSON.stringify(
      { ...payload, createdAt: new Date().toISOString() },
      null,
      4
    );

    try {
      const res = await fetch(`${API_BASE}/signups`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload), 
      });

      if (!res.ok) {
        const errBody = await res.json().catch(() => ({}));
        throw new Error(errBody.error || "Server error");
      }

      alert("Signup saved to database!");
    } catch (err) {
      console.error("Error saving signup:", err);
      alert("Error during signup: " + err.message);
    }
  });
});
